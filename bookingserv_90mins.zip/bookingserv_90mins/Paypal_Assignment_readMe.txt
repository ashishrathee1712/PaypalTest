Notes:
1. Create API to Fetch and Create Booking 
2. Written 2 test cases to demonstrate Junits with Mockito
3. Pending - Validations of Date Format in Request

NOTE:  IF we pass Same First Name and Last Name - It will considerr it as duplicate and will throw bad request

APIs:

GET ALL BOOKING:
http://localhost:9000/v1/bfs/booking

Create Booking:
curl -X POST \
  http://localhost:9000/v1/bfs/booking \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/json' \
  -H 'postman-token: ca654ea5-89c3-8ef3-b30d-b3bf08915e28' \
  -d '{
	"first_name" : "Ashish",
	"last_name" : "Kumar",
	"dob" : "2000-10-01T09:45:00.000",
	"checkin_datetime" : "2021-10-01T09:45:00.000",
	"checkout_datetime" : "2021-10-01T09:45:00.000",
	"totalprice" : 1000,
	"deposit" : 500,
	"address" : {
		"line1" : "Sector 2000",
		"line2" : "Mumbai Road",
		"city" : "Gurgaon",
		"state" : "Haryana",
		"zip_code" : "122001"
	}
}'

