package com.paypal.bfs.test.bookingserv;

import com.paypal.bfs.test.bookingserv.api.model.Address;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.impl.domainobject.BookingDO;
import com.paypal.bfs.test.bookingserv.impl.exception.DuplicateBookingException;
import com.paypal.bfs.test.bookingserv.impl.repository.BookingRepository;
import com.paypal.bfs.test.bookingserv.impl.service.BookingServiceImpl;
import com.paypal.bfs.test.bookingserv.impl.service.mapper.AddressMapper;
import com.paypal.bfs.test.bookingserv.impl.service.mapper.BookingMapper;
import com.paypal.bfs.test.bookingserv.service.BookingService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.util.Assert;

import java.time.Instant;
import java.util.Date;
import java.util.Optional;

@RunWith(MockitoJUnitRunner.class)
public class BookingServiceImplTest {

    @InjectMocks
    private BookingServiceImpl bookingService;

    @Mock
    private BookingRepository bookingRepository;

    @Test
    public void createBookingTest() {
        Booking booking = getBookingStub();
        Mockito.when(bookingRepository.findByFirstNameAndLastName(Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.empty());
        Mockito.when(bookingRepository.save(Mockito.any(BookingDO.class))).thenReturn((BookingMapper.makeBookingDO(booking)));
        Booking actual = bookingService.create(booking);
        Assert.notNull(actual);
        Assert.isTrue(booking.getId() == 1);
    }

    @Test(expected = DuplicateBookingException.class)
    public void bookingAlreadyExists() {
        Booking booking = getBookingStub();
        Mockito.when(bookingRepository.findByFirstNameAndLastName(Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.of(BookingMapper.makeBookingDO(booking)));
        Booking actual = bookingService.create(booking);
    }

    private Booking getBookingStub() {
        Booking booking = new Booking();
        booking.setId(1);
        booking.setFirstName("Ashish");
        booking.setLastName("Rathee");
        booking.setDob(new Date());
        booking.setCheckinDatetime(new Date());
        booking.setCheckoutDatetime(new Date());
        booking.setTotalprice(1000);
        booking.setDeposit(5000);

        Address address = new Address();
        address.setLine1("H NO 1");
        address.setLine2("Chandni Chowk");
        address.setCity("Delhi");
        address.setState("Delhi");
        address.setZipCode("122001");
        booking.setAddress(address);
        return booking;
    }
}
