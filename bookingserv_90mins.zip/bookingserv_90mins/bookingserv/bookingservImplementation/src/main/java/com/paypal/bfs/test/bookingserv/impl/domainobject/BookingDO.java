package com.paypal.bfs.test.bookingserv.impl.domainobject;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.ZonedDateTime;

@Entity
@Table(name = "booking")
public class BookingDO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false)
    private String firstName;
    @Column(nullable = false)
    private String lastName;

    @Column(name = "dob", nullable = false)
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime dob;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    @Column(name = "checkin_datetime", nullable = false)
    private ZonedDateTime checkinDatetime;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    @Column(name = "checkout_datetime", nullable = false)
    private ZonedDateTime checkoutDatetime;

    @Column(name = "totalprice", nullable = false)
    private Integer totalprice;
    @Column(name = "deposit", nullable = false)
    private Integer deposit;

    @OneToOne(mappedBy = "bookingDO", fetch = FetchType.LAZY,
            cascade = CascadeType.ALL)
    private AddressDO address;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public ZonedDateTime getDob() {
        return dob;
    }

    public void setDob(ZonedDateTime dob) {
        this.dob = dob;
    }

    public ZonedDateTime getCheckinDatetime() {
        return checkinDatetime;
    }

    public void setCheckinDatetime(ZonedDateTime checkinDatetime) {
        this.checkinDatetime = checkinDatetime;
    }

    public ZonedDateTime getCheckoutDatetime() {
        return checkoutDatetime;
    }

    public void setCheckoutDatetime(ZonedDateTime checkoutDatetime) {
        this.checkoutDatetime = checkoutDatetime;
    }

    public Integer getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(Integer totalprice) {
        this.totalprice = totalprice;
    }

    public Integer getDeposit() {
        return deposit;
    }

    public void setDeposit(Integer deposit) {
        this.deposit = deposit;
    }

    public AddressDO getAddress() {
        return address;
    }

    public void setAddress(AddressDO address) {
        this.address = address;
    }

    public BookingDO() {
    }

    public BookingDO(String firstName, String lastName, ZonedDateTime dob, ZonedDateTime checkinDatetime, ZonedDateTime checkoutDatetime, Integer totalprice, Integer deposit, AddressDO address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.checkinDatetime = checkinDatetime;
        this.checkoutDatetime = checkoutDatetime;
        this.totalprice = totalprice;
        this.deposit = deposit;
        this.address = address;
    }
}
