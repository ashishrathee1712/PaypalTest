package com.paypal.bfs.test.bookingserv.impl.service.mapper;

import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.impl.domainobject.AddressDO;
import com.paypal.bfs.test.bookingserv.impl.domainobject.BookingDO;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class BookingMapper {
    private BookingMapper()
    {
    }

    public static BookingDO makeBookingDO(Booking booking) {
        AddressDO addressDO = AddressMapper.makeAddressDO(booking.getAddress());
        BookingDO bookingDO = new BookingDO(
                    booking.getFirstName(),
                    booking.getLastName(),
                    booking.getDob() == null ? null : ZonedDateTime.ofInstant(booking.getDob().toInstant(), ZoneId.of("UTC")),
                    booking.getCheckinDatetime() == null ? null : ZonedDateTime.ofInstant(booking.getCheckinDatetime().toInstant(), ZoneId.of("UTC")),
                    booking.getCheckoutDatetime() == null ? null : ZonedDateTime.ofInstant(booking.getCheckoutDatetime().toInstant(), ZoneId.of("UTC")),
                    booking.getTotalprice(),
                    booking.getDeposit(),
                    addressDO
                );
        addressDO.setBookingDO(bookingDO);
        return bookingDO;
    }

    public static Booking makeBookingDTO(BookingDO bookingDO) {
        // TODO -  Should be builder
        Booking booking = new Booking();
        booking.setId(bookingDO.getId());
        booking.setFirstName(bookingDO.getFirstName());
        booking.setLastName(bookingDO.getLastName());
        booking.setDob(bookingDO.getDob() == null ? null : Date.from(bookingDO.getDob().toInstant()));
        booking.setCheckinDatetime(bookingDO.getCheckinDatetime() == null ? null : Date.from(bookingDO.getCheckinDatetime().toInstant()));
        booking.setCheckoutDatetime(bookingDO.getCheckoutDatetime() == null ? null : Date.from(bookingDO.getCheckoutDatetime().toInstant()));
        booking.setTotalprice(bookingDO.getTotalprice());
        booking.setDeposit(bookingDO.getDeposit());
        booking.setAddress(AddressMapper.makeAddressDTO(bookingDO.getAddress()));
        return booking;
    }

    public static List<Booking> makeBookingDTOList(Collection<BookingDO> bookings)
    {
        return bookings
                .stream()
                .map(BookingMapper::makeBookingDTO)
                .collect(Collectors.toList());
    }
}
