package com.paypal.bfs.test.bookingserv.impl.service.mapper;

import com.paypal.bfs.test.bookingserv.api.model.Address;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.impl.domainobject.AddressDO;
import com.paypal.bfs.test.bookingserv.impl.domainobject.BookingDO;

public class AddressMapper {
    private AddressMapper() {}

    public static AddressDO makeAddressDO(Address address) {
        return new AddressDO(
                address.getLine1(),
                address.getLine2(),
                address.getCity(),
                address.getState(),
                address.getZipCode()
        );
    }

    public static Address makeAddressDTO(AddressDO addressDO) {
        Address address = new Address();
        address.setLine1(addressDO.getLine1());
        address.setLine2(addressDO.getLine2());
        address.setCity(addressDO.getCity());
        address.setState(addressDO.getState());
        address.setZipCode(addressDO.getZipCode());
        return address;
    }
}
