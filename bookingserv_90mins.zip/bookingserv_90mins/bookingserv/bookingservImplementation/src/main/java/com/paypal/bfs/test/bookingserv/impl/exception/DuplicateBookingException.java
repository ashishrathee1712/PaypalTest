package com.paypal.bfs.test.bookingserv.impl.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Booking already Exists for this user ")
public class DuplicateBookingException extends RuntimeException {
    public DuplicateBookingException(String message)
    {
        super(message);
    }
}
