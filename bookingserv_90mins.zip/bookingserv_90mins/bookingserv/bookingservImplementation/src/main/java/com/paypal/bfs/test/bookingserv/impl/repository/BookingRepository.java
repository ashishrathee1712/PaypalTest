package com.paypal.bfs.test.bookingserv.impl.repository;

import com.paypal.bfs.test.bookingserv.impl.domainobject.BookingDO;
import org.springframework.data.repository.CrudRepository;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository extends CrudRepository<BookingDO, Long> {
    Optional<BookingDO> findByFirstNameAndLastName(String firstName, String lastName);
    @Override
    List<BookingDO> findAll();
}
