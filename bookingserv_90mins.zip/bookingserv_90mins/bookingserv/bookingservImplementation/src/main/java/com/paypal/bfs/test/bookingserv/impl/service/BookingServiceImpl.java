package com.paypal.bfs.test.bookingserv.impl.service;

import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.impl.domainobject.BookingDO;
import com.paypal.bfs.test.bookingserv.impl.exception.DuplicateBookingException;
import com.paypal.bfs.test.bookingserv.impl.repository.BookingRepository;
import com.paypal.bfs.test.bookingserv.impl.service.mapper.BookingMapper;
import com.paypal.bfs.test.bookingserv.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;

    public BookingServiceImpl(@Autowired BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @Override
    public Booking create(Booking booking) {
        Optional<BookingDO> bookingDO = bookingRepository.findByFirstNameAndLastName(booking.getFirstName(), booking.getLastName());
        if (bookingDO.isPresent()) {
            throw new DuplicateBookingException(String.format("Booking Already Exist for %s %s", booking.getFirstName(), booking.getLastName()));
        }
        return BookingMapper.makeBookingDTO(bookingRepository.save(BookingMapper.makeBookingDO(booking)));
    }

    @Override
    public List<Booking> getAll() {
        return BookingMapper.makeBookingDTOList(bookingRepository.findAll());
    }
}
